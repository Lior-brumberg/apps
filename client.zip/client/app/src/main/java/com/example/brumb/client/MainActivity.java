package com.example.brumb.client;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    EditText e1;
    Button send;
    private static Socket s;
    private static InputStreamReader isr;
    private static BufferedReader br;
    private static PrintWriter printWriter;

    private static String msg = "";
    private static String ip = "192.168.14.47";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = (EditText) findViewById(R.id.e1);


    }

    public void send_text(View v)
    {
        msg = e1.getText().toString();

        myTask mt = new myTask();
        mt.execute();

        Toast.makeText(getApplicationContext(), "Data sent", Toast.LENGTH_LONG).show();


    }

    static class myTask extends AsyncTask<Void,Void,Void>{
        @Override
        protected Void doInBackground(Void... voids) {
            try
            {

                s = new Socket(ip, 32121);
                printWriter = new PrintWriter(s.getOutputStream());
                printWriter.write(msg);
                printWriter.flush();
                s.close();


            } catch (IOException e) {
                e.printStackTrace();
            }
        return null;
        }
    }

}
